**Run project**

```
$ npm install

```

gulp build - сборка проекта
gulp watch - сборка проекта + livereload  // press F5
gulp clear - очистка папки /dist


